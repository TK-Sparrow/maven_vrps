/**
 * 
 */

window.addEventListener('load',function()
		{
	var ajaxObject=null;
	try{
		ajaxObject=new XMLHttpRequest();
	}
	catch(e){
		try{
			ajaxObject=new ActiveXObject("Msxml2.XMLHTTP3.0");
		}

		catch(e){
			alert("browser is broken or ajax ");
		}
	}
	ajaxObject.open("get","../JobProcessList",true);
	ajaxObject.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
	ajaxObject.send(null);
	
	ajaxObject.onreadystatechange=function()
	{
		if((ajaxObject.readyState==4) && (ajaxObject.status=200)){
			
			data=JSON.parse(ajaxObject.responseText);
			
			
			
			
		}
	}
	
});