/**
 * 
 */

function search_func() {
	  var input, filter, table, tr, td, i, txtValue;
	  input = document.getElementById("search");
	  filter = input.value.toUpperCase();
	  table = document.getElementById("myTable");
	  tr = table.getElementsByTagName("tr");
	  for (i = 1; i < tr.length; i++) {
	    td = tr[i].getElementsByTagName("td")[7];
	    if (td) {
	      txtValue = td.textContent || td.innerText;
	      if (txtValue.toUpperCase().indexOf(filter) > -1) {
	        tr[i].style.display = "";
	      } else {
	        tr[i].style.display = "none";
	      }
	    }       
	  }
	}

window.addEventListener('load',function()
		{
	var ajaxObject=null;
	try{
		ajaxObject=new XMLHttpRequest();
	}
	catch(e){
		try{
			ajaxObject=new ActiveXObject("Msxml2.XMLHTTP3.0");
		}

		catch(e){
			alert("browser is broken or ajax ");
		}
	}
	
	var type=document.querySelector("#type").value;
	
	console.log("search "+search);
	ajaxObject.open("post","../ViewEmployeeList",true);
	ajaxObject.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
	ajaxObject.send("type="+type);
	
	ajaxObject.onreadystatechange=function()
	{
		if((ajaxObject.readyState==4) && (ajaxObject.status=200)){
			
			data=JSON.parse(ajaxObject.responseText);
			console.log(data);
			var tableRef=document.querySelector("table");
			
			for(var pos in data){
				row=document.createElement("tr");
				for(var innerpos in data[pos]){
					col=document.createElement("td");
					textNode=document.createTextNode(innerpos.toUpperCase());
					col.appendChild(textNode);
					row.appendChild(col);				
			}
			tableRef.appendChild(row);
			break;
		}
			
			for(var pos in data){
				row=document.createElement("tr");
				console.log(pos+" "+data[pos]);
				for(var innerpos in data[pos]){
					console.log(innerpos+" "+data[pos][innerpos])
					col=document.createElement("td");
					a=document.createElement("a");
					a.setAttribute('href','employeeDetails.jsp?id='+data[pos]['empID']);
									
					textNode=document.createTextNode(data[pos][innerpos]);
					
					a.appendChild(textNode);
					col.append(a);
					row.appendChild(col);
					
				}
				tableRef.appendChild(row);
				
			}
			
		}
	}
	
});