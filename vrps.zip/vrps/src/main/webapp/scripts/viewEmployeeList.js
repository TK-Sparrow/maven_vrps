/**
 * 
 */


window.addEventListener('load',function()
		{
	var ajaxObject=null;
	try{
		ajaxObject=new XMLHttpRequest();
	}
	catch(e){
		try{
			ajaxObject=new ActiveXObject("Msxml2.XMLHTTP3.0");
		}

		catch(e){
			alert("browser is broken or ajax ");
		}
	}
	
	ajaxObject.open("get","../ViewEmployeeList",true);
	ajaxObject.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
	ajaxObject.send(null);
	
	ajaxObject.onreadystatechange=function()
	{
		if((ajaxObject.readyState==4) && (ajaxObject.status=200)){
			
			data=JSON.parse(ajaxObject.responseText);
			console.log(data);
			var tableRef=document.querySelector("table");
			
			for(var pos in data){
				row=document.createElement("tr");
				for(var innerpos in data[pos]){
					col=document.createElement("td");
					textNode=document.createTextNode(innerpos.toUpperCase());
					col.appendChild(textNode);
					row.appendChild(col);				
			}
			tableRef.appendChild(row);
			break;
		}
			
			for(var pos in data){
				row=document.createElement("tr");
				console.log(pos+" "+data[pos]);
				for(var innerpos in data[pos]){
					console.log(innerpos+" "+data[pos][innerpos])
					col=document.createElement("td");
					a=document.createElement("a");
					a.setAttribute('href','employeeDetails.jsp?id='+data[pos]['empID']);
									
					textNode=document.createTextNode(data[pos][innerpos]);
					
					a.appendChild(textNode);
					col.append(a);
					row.appendChild(col);
					
				}
				tableRef.appendChild(row);
				
			}
			
		}
	}
	
});