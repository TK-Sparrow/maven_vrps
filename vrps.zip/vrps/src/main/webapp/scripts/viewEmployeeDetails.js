/**
 * 
 */
window.addEventListener('load',function()
		{
	var ajaxObject=null;
	try{
		ajaxObject=new XMLHttpRequest();
	}
	catch(e){
		try{
			ajaxObject=new ActiveXObject("Msxml2.XMLHTTP3.0");
		}

		catch(e){
			alert("browser is broken or ajax ");
		}
	}
	
	ajaxObject.open("post","../ViewEmployeeDetails",true);
	ajaxObject.setRequestHeader("Content-Type","application/x-www-form-urlencoded;");
	var empID=document.querySelector("#empID").value;
	ajaxObject.send("empID="+empID);
	console.log(empID)
	ajaxObject.onreadystatechange=function()
	{
		if((ajaxObject.readyState==4) && (ajaxObject.status=200)){
			
			data=JSON.parse(ajaxObject.responseText);
			var divRef=document.querySelector("div");
			
			
		
			
			for(var pos in data){
				var h3Ref=document.createElement("h3");
				if(pos!='employeeId' && pos!='referenceId'){
					console.log(pos);
					textNodePos=document.createTextNode(pos);
					h3Ref.appendChild(textNodePos);
					for(var innerpos in data[pos]){
						var h4Ref=document.createElement("h4");
						textNode=document.createTextNode(innerpos+" : "+data[pos][innerpos]);
						h4Ref.appendChild(textNode);
						h3Ref.appendChild(h4Ref);
					}
				}
				else{
					textNode=document.createTextNode(pos+" : "+data[pos]);
					h3Ref.appendChild(textNode);
				}
				
				divRef.appendChild(h3Ref);
			}
					/*col=document.createElement("td");
					
									
					textNode=document.createTextNode(data[pos][innerpos]);
					
					a.appendChild(textNode);
					col.append(a);
					row.appendChild(col);
					
				}
				divRef.appendChild(row);
				
			}*/
			
		}
	}
	
});