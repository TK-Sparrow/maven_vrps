package com.virtusa.vrps.dao.interfaces;

import java.sql.SQLException;
import java.util.List;

import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.Users;
import com.virtusa.vrps.models.WorkDetails;

public interface UsersDao {
	List<Users> getAllUsers() throws SQLException;

	boolean setCreateProfile(Employee employee) throws SQLException;
	
	Employee getEmployeeDetails(String employeeID) throws SQLException;
	
	List<WorkDetails> getWorkDetails() throws SQLException;

}
