package com.virtusa.vrps.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.virtusa.vrps.dao.implementations.JobProcessListImp;
import com.virtusa.vrps.dao.interfaces.ProcessList;
import com.virtusa.vrps.models.JobProcessList;

/**
 * Servlet implementation class NewProcessList
 */
@WebServlet(asyncSupported = true, urlPatterns = { "/NewProcessList" })
public class NewProcessList extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public NewProcessList() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		
		String userID=null;
		/*
		 * Cookie a[]=request.getCookies(); for(int i=0;i<a.length;i++){
		 * if(a[i].getName().equals("userID")){ userID=a[i].getValue(); break; } }
		 */
		userID="786543";
		
		LocalDate localDate = LocalDate.now();
		
		String processName=request.getParameter("processName");
		String processCode=request.getParameter("processCode");
		String description=request.getParameter("description");
		JobProcessList processList=new JobProcessList();
		processList.setProcessName(processName);
		processList.setDescrption(description);
		processList.setCreatedDate(localDate);
		processList.setProcessCode(processCode);
		processList.setCreatorName(userID);
		
		ProcessList addList=new JobProcessListImp();
		Boolean status=addList.addProcess(processList);
		System.out.println("status : "+status);
	}

}
