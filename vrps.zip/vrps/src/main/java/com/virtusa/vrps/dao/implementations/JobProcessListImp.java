package com.virtusa.vrps.dao.implementations;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import com.virtusa.vrps.dao.interfaces.ProcessList;
import com.virtusa.vrps.models.JobProcessList;

public class JobProcessListImp implements ProcessList {
	
	private Connection conn;
	private CallableStatement callable;
	private boolean status=false;
	private static ResourceBundle rb;
	private Statement statement;
	private ResultSet resultSet;

	{
		rb = ResourceBundle.getBundle("db");
	}

	@Override
	public boolean addProcess(JobProcessList jobProcessList) {
		// TODO Auto-generated method stub
		
		return false;
	}

	@Override
	public boolean deleteProcess(String processName) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean update(JobProcessList jobProcessList) {
		// TODO Auto-generated method stub
		
		
		return false;
	}

}
