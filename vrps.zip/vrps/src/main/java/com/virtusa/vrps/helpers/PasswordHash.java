package com.virtusa.vrps.helpers;

import java.math.BigInteger;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class PasswordHash {

	public String getHash(String password) {

		MessageDigest md;
		byte[] enc_pass=null;
		try {
			md = MessageDigest.getInstance("MD5");
			byte[] pass_b = password.getBytes(StandardCharsets.UTF_8);
			enc_pass = (md.digest(pass_b));

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		BigInteger number = new BigInteger(1,enc_pass); 

		StringBuilder hexString = new StringBuilder(number.toString(16)); 

		while (hexString.length() < 32) 
		{ 
			hexString.insert(0, '0'); 
		} 
		
		return hexString.toString();
	}

}
