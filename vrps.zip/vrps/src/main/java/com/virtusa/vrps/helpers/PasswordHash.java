package com.virtusa.vrps.helpers;

import java.security.MessageDigest;

public class PasswordHash {

	public String getHash(String password) {

		MessageDigest messageDigest;
		String hashedPassword = null;
		try {
			messageDigest = MessageDigest.getInstance("MD5");
			byte[] hashedBytes = password.getBytes();
			hashedPassword = new String(messageDigest.digest(hashedBytes));

		} catch (Exception e) {
			e.printStackTrace();
		}
		return hashedPassword;
	}

}
