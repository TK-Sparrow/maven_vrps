package com.virtusa.vrps.models;

public class AllUserDetails {
	private PersonalDetails personalDetails;
	private EducationDetails educationalDetails;
	private Projects projects;
	private WorkDetails workDetails;
	
	public PersonalDetails getPersonalDetails() {
		return personalDetails;
	}
	public void setPersonalDetails(PersonalDetails personalDetails) {
		this.personalDetails = personalDetails;
	}
	public EducationDetails getEducationalDetails() {
		return educationalDetails;
	}
	public void setEducationalDetails(EducationDetails educationalDetails) {
		this.educationalDetails = educationalDetails;
	}
	public Projects getProjects() {
		return projects;
	}
	public void setProjects(Projects projects) {
		this.projects = projects;
	}
	public WorkDetails getWorkDetails() {
		return workDetails;
	}
	public void setWorkDetails(WorkDetails workDetails) {
		this.workDetails = workDetails;
	}
}
