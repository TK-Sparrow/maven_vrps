package com.virtusa.vrps.models;

public class UserDetailsAll {
	
	private EducationDetails educationDetails;
	private PersonalDetails personalDetails;
	public EducationDetails getEducationDetails() {
		return educationDetails;
	}
	public void setEducationDetails(EducationDetails educationDetails) {
		this.educationDetails = educationDetails;
	}
	public PersonalDetails getPersonalDetails() {
		return personalDetails;
	}
	public void setPersonalDetails(PersonalDetails personalDetails) {
		this.personalDetails = personalDetails;
	}

}
