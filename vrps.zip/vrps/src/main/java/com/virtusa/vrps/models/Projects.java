package com.virtusa.vrps.models;

import java.util.Date;

public class Projects {
	private String title;
	private Date startdate;
	private Date enddate;
	private String description;

	public Projects(String title, Date startdate, Date enddate, String description) {
		super();
		this.title = title;
		this.startdate = startdate;
		this.enddate = enddate;
		this.description = description;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Date getStartdate() {
		return startdate;
	}

	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}

	public Date getEnddate() {
		return enddate;
	}

	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}

}
