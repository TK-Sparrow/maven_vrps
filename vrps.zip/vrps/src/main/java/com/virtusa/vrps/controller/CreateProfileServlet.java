package com.virtusa.vrps.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Enumeration;
import java.util.Random;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.vrps.dao.implementations.UsersImp;
import com.virtusa.vrps.dao.interfaces.UsersDao;
import com.virtusa.vrps.models.EducationDetails;
import com.virtusa.vrps.models.Employee;
import com.virtusa.vrps.models.PersonalDetails;
import com.virtusa.vrps.models.Projects;
import com.virtusa.vrps.models.WorkDetails;

/**
 * Servlet implementation class CreateProfileServlet
 */
@WebServlet("/CreateProfileServlet")
public class CreateProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		PrintWriter out = response.getWriter();
		response.setContentType("text/plain");

		Enumeration<String> parameterNames = request.getParameterNames();

		HttpSession session = request.getSession();
		Random rand = new Random();
		String paramName = null;
		String[] paramValues = new String[40];
		int i = 0;

		while (parameterNames.hasMoreElements()) {
			String string = (String) parameterNames.nextElement();
			paramValues[i] = request.getParameter(string);
			i++;

		}

		try {
			PersonalDetails personalDetails = new PersonalDetails(paramValues[0], toDate(paramValues[1]),
					paramValues[2], Long.parseLong(paramValues[3]), paramValues[4], paramValues[5]);

			WorkDetails workDetails = new WorkDetails(paramValues[6], toNumber(paramValues[7]), paramValues[8],
					paramValues[9], toNumber(paramValues[10]), paramValues[11], paramValues[12]);

			Projects projects = new Projects(paramValues[13], toDate(paramValues[14]), toDate(paramValues[15]),
					paramValues[16]);
			System.out.println(paramValues[17]+" "+paramValues[18]+" "+paramValues[19]+" "+paramValues[20]+" "+paramValues[21]+" "+paramValues[22]+" "+paramValues[23]+" "+paramValues[24]+" "+paramValues[25]+" "+paramValues[26]+" "+paramValues[27]+" "+paramValues[28]+" "+paramValues[29]);
			EducationDetails educationDetails = new EducationDetails(paramValues[17], toNumber(paramValues[18]),
					toNumber(paramValues[19]), paramValues[21], toNumber(paramValues[22]), toNumber(paramValues[23]),
					paramValues[24], paramValues[25], toNumber(paramValues[26]), toNumber(paramValues[27]),
					paramValues[28], paramValues[29], toNumber(paramValues[30]), toNumber(paramValues[31]));

			int random = rand.nextInt(1000);
			String employeeId = (String) session.getAttribute("employeeId");
			String referenceId = random + "" + employeeId;

			Employee employee = new Employee(employeeId, educationDetails, personalDetails, workDetails, projects,
					referenceId);
			System.out.println(employeeId);
			System.out.println(employee.getEmployeeId() + " " + employee.getPersonalDetails().getFullName() + " "
					+ employee.getPersonalDetails().getDob() + " " + employee.getPersonalDetails().getAddress() + " "
					+ employee.getPersonalDetails().getEmail() + " " + employee.getPersonalDetails().getMobile()
					+ "	" + employee.getPersonalDetails().getGender() + " "

			);

			UsersDao usersDao = new UsersImp();

			boolean result = usersDao.setCreateProfile(employee);

		} catch (NumberFormatException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	private static java.util.Date toDate(String dateString) throws ParseException {
		java.util.Date date = (java.util.Date) new SimpleDateFormat("yyyy-MM-dd").parse(dateString);
		return date;

	}

	private static int toNumber(String numberString) {
		return Integer.parseInt(numberString);
	}

}
