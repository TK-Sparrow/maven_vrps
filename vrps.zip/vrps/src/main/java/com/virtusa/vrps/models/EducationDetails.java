package com.virtusa.vrps.models;

public class EducationDetails {
	private String schoolName;
	private String schoolPercent;
	private String schoolPassYear;

	private String collegeName;
	private String collegePercent;
	private String collegePassYear;

	private String engCollegeName;
	private String engPercent;
	private String engPassYear;
	private String engCourseType;

	private String pGCollegeName;
	private String pGPercent;
	private String pGPassYear;
	private String pGCourseType;

	public String getSchoolName() {
		return schoolName;
	}

	public void setSchoolName(String schoolName) {
		this.schoolName = schoolName;
	}

	public String getSchoolPercent() {
		return schoolPercent;
	}

	public void setSchoolPercent(String schoolPercent) {
		this.schoolPercent = schoolPercent;
	}

	public String getSchoolPassYear() {
		return schoolPassYear;
	}

	public void setSchoolPassYear(String schoolPassYear) {
		this.schoolPassYear = schoolPassYear;
	}

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	public String getCollegePercent() {
		return collegePercent;
	}

	public void setCollegePercent(String collegePercent) {
		this.collegePercent = collegePercent;
	}

	public String getCollegePassYear() {
		return collegePassYear;
	}

	public void setCollegePassYear(String collegePassYear) {
		this.collegePassYear = collegePassYear;
	}

	public String getEngCollegeName() {
		return engCollegeName;
	}

	public void setEngCollegeName(String engCollegeName) {
		this.engCollegeName = engCollegeName;
	}

	public String getEngPercent() {
		return engPercent;
	}

	public void setEngPercent(String engPercent) {
		this.engPercent = engPercent;
	}

	public String getEngPassYear() {
		return engPassYear;
	}

	public void setEngPassYear(String engPassYear) {
		this.engPassYear = engPassYear;
	}

	public String getEngCourseType() {
		return engCourseType;
	}

	public void setEngCourseType(String engCourseType) {
		this.engCourseType = engCourseType;
	}

	public String getpGCollegeName() {
		return pGCollegeName;
	}

	public void setpGCollegeName(String pGCollegeName) {
		this.pGCollegeName = pGCollegeName;
	}

	public String getpGPercent() {
		return pGPercent;
	}

	public void setpGPercent(String pGPercent) {
		this.pGPercent = pGPercent;
	}

	public String getpGPassYear() {
		return pGPassYear;
	}

	public void setpGPassYear(String pGPassYear) {
		this.pGPassYear = pGPassYear;
	}

	public String getpGCourseType() {
		return pGCourseType;
	}

	public void setpGCourseType(String pGCourseType) {
		this.pGCourseType = pGCourseType;
	}

}
